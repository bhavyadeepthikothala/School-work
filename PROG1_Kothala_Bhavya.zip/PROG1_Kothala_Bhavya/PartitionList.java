/****************************************************************************************
 * Program: PartitionList
 *Description:
 *            This program accepts the input and creates a single Linked List and
 *            also accepts a reference variable that is used to rearrange the list 
 *            such that all the elements less than the reference variable comes before 
 *            the reference value. To do so we call a function thats written in another 
 *            class PartitionLinkedList by using an object created to that class.
 *            Once the function returns a list print the list.   
 *
 ****************************************************************************************/
public class PartitionList {

	public static void main(String[] args) 
   {
		// TODO Auto-generated method stub

		PartitionLinkedList PLL = new PartitionLinkedList();  // creating an object for the class PartitionLinkedList
		
		// List of nodes with different values 
		ListNode head = new ListNode(1);
		ListNode first = new ListNode(4);
		ListNode second = new ListNode(3);
		ListNode third = new ListNode(2);
		ListNode fourth = new ListNode(5);
		ListNode last = new ListNode(2);
		//creating the list 
		head.next = first;
		first.next = second;
		second.next = third;
		third.next = fourth;
		fourth.next = last;
		
        // reference variable with which values in list are to be compared to arrange
		int x = 3;
        // print the given linked list
		ListNode ForPrint = head;
		System.out.print("Given ");
		while(ForPrint != null)
		{
			System.out.print(ForPrint.val);
			ForPrint = ForPrint.next;
			if(ForPrint != null)
			{
				System.out.print(" -> ");
			}
		}
      System.out.println(" and x = " + x);
		
        // print the rearranged list 
		head = PLL.partition(head,x);	// call the function Partition
		
		ListNode curr = head;
      
		System.out.print("return ");
		while(curr != null)
		{
			System.out.print(curr.val);
			curr = curr.next;
			if(curr != null)
			{
				System.out.print(" -> ");
			}
		}		
		
   }	
}