/************************************************************************************************
 * Author: Bhavya Deepthi Kothala
 * Description: This program is about filling a matrix spirally starting from 1 to n*n
 *  
 * Working:
 *         This program accepts the input from user for the value of n and keeps a counter 
 *         that counts all the numbers that are filled till now.
 *         Has one function that fills matrix spirally and the main function that reads a 
 *         value from the user.
 *         
 *          In function we have four indexes as,
 *          Left: This indicates the left most column index that is incremented linearly so that
 *                left = right to end the loop and filling the matrix
 *          Right: This indicates the Right most column index that is decremented linearly so that
 *                 right = left to end the loop and filling the matrix
 *          Top: This indicates the top most row of the matrix that is incremented linearly so that
 *                 top = bottom to end the loop and filling the matrix
 *          Bottom: This indicates the Last column of the matrix that is decremented linearly so that
 *                 bottom = top to end the loop and filling the matrix  
 *                 
 *                 we start filling the first row or the to most row first then increment the 
 *                 top value so that the top, now points to second row of matrix and then fill
 *                 last or right most column starting from the current top uptil the bottom and 
 *                 decrement the right, now the right points to second last column of the matrix.
 *                 Then we fill the last row of the matrix starting from current right uptil the 
 *                 left and decrement the bottom so that the new bottom will point to the second 
 *                 last row of the matrix then we fill the left most or the first column of the
 *                 matrix starting from current bottom uptil the current top.
 *                 
 *                  This Process continues until top equals to bottom and left equals to right.
 *             
 ************************************************************************************************/


import java.util.*;
public class SpiralMatrix 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

		Scanner in = new Scanner(System.in);
        System.out.print("Please enter the number : ");   // to read a value from the user
        String input = in.nextLine();       
		int number = Integer.parseInt(input);
		int SM[][] = fillMatrixSpirally(number);  // call a function to fill matrix spirally
		for(int i = 0; i < number; i++)              
		{
			for(int j = 0;j < number; j++)
			{
				if(SM[i][j] <= 9)
				{
					System.out.print(SM[i][j] + "  ");    // Printing the matrix 
				}
				else
				{	
			    	System.out.print(SM[i][j] + " ");
				}
			}//end inner for loop
			System.out.println();
		}//end for
		
	}//end main
    
	// Function to fill the matrix spirally and return it to main so main can print it
	public static int[][] fillMatrixSpirally(int n)
	{
		int left = 0;   //left most column index
		int top = 0;    // top most row index
		int right = n;    // right most column index
		int bottom = n;      // bottom most row index
		
		int num =1;
		int[][] SM = new int[n][n];
		while(left < right && top < bottom && num <= n*n )
		{
			
			for (int i = left; i < right; i++)
			{
				SM[top][i] = num;
				num++;
			}
						
			top ++;  //increment top most row index
			
			if(top >= bottom)
				break;
			
			
			for (int i = top; i < bottom; i++)
			{
				SM[i][right-1]  = num;
				num++;
			}
					
			right --;    // decrement the right most column index
			
			if(left >= right) 
				break;
			
			for (int i = right-1; i >= left; i--)
			{
				SM[bottom-1][i] = num;
				num++;
			}
					
			bottom--;    // decrement the bottom most row index
			
			if(top >= bottom) 
				break;
			
			for (int i = bottom-1; i >= top; i--)
			{
				SM[i][left] = num;
				num++;
			}
						
			left ++;          // increment the left most column index
		}
		return SM;  // return the matrix
	}//end of function
	
}//end class