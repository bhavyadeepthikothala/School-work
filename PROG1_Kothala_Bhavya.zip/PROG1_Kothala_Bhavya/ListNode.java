
/* Definition for singly-linked list. */ 

class ListNode 
{
      int val;
      ListNode next;
      ListNode(int x) 
      {
          val = x;     // value stored in the list
          next = null; // pointer to the next node by default is null 
      }
  }