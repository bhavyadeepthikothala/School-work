/***********************************************************************************************
 * Author: Bhavya Deepthi Kothala
 * Description:
 *              This class have a function "mergeTwoLists" that actually combines two sorted
 *              Linked lists into a single list and then return it to the calling function
 *              
 *              In function, we checked the value of first element of the list 1 with first 
 *              element of second list whichever is smaller becomes the first element of the
 *              new list. 
 *              This process of comparing and adding elements to the new list continues until 
 *              one of the list is completely finishedand then the elements of other list are 
 *              appended in the end.
 ***********************************************************************************************/


public class MergeList 
{
	public ListNode mergeTwoLists(ListNode l1, ListNode l2) 
	{
		 
        ListNode p1 = l1;
        ListNode p2 = l2;
 
        ListNode Head = new ListNode(0);
        ListNode p = Head;
 
        while(p1 != null && p2 != null){
          if(p1.val <= p2.val){
              p.next = p1;
              p1 = p1.next;
          }else{
              p.next = p2;
              p2 = p2.next;
          }
 
          p = p.next;
        }
 
        while(p1 != null)
        {
        	p.next = p1;
        	p1 = p1.next;
        	p = p.next;
        }
            
        while(p2 != null)
        {
        	p.next = p2;
        	p2 = p2.next;
        	p = p.next;
        }
            
 
        return Head.next;
    }
}
