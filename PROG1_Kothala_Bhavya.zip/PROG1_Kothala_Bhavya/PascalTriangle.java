/*****************************************************************************************
 * Author: Bhavya Deepthi Kothala
 * Description: 
 *             This Program accepts the no of rows in the pascal triangle to be printed 
 *             and passes it to a function and the function creates an arraylist and prints 
 *             it in the form of a triangle
 *             
 *             The first and last element of each row in the array list is always 1
 *             The first row is always one and the second row is always 1,1
 *             Now from the third row will have three elements and the center elements will 
 *             be sum of the first element and the second element in the previous row
 *             
 *             As this process continues , I have used recursion to solve the problem
 *             changing the no. of rows already printed everytime we pass the values
 *****************************************************************************************/


import java.util.ArrayList;


public class PascalTriangle 
{

    public static void main(String[] args) {

        int noOfRows = 5;	// No. of rows of pascal Triangle needed to be printed 
        int printedRows = 1;  // no. of rows already printed
        ArrayList<Integer> list = new ArrayList<Integer>(); // array list to store the pascal triangle
        list.add(1);

        list = pascalTriangle(list, printedRows,noOfRows); // call function to create and print pascal triangle
    }
 
    //Function to create and print pascal Triangle
    public static ArrayList<Integer> pascalTriangle(ArrayList<Integer> list, int PrintedRows,int noOfRows) 
    {
    	
    	if(list.size() == 1)
    	{
    		System.out.print("[");
    	}
    	for(int i = 0; i < noOfRows - PrintedRows;i++)
    	{
    		System.out.print(" ");
    	}
    	
    	if( list.size() == noOfRows)
    	{
    		System.out.print(list + "]");
    			
    	}
    	else
    	{
            System.out.println(list + "\n");
    	}
    	
        ArrayList<Integer> tempList = new ArrayList<Integer>();

        tempList.add(1);
        
        for (int i = 1; i < list.size(); i++) 
        {
            tempList.add(list.get(i) + list.get(i-1));
        }
        
        tempList.add(1);

        if(PrintedRows!= noOfRows)
            pascalTriangle(tempList, ++PrintedRows,noOfRows); 	

        return tempList;
    }
}