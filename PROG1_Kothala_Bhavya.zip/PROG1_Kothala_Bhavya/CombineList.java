/**********************************************************************************
 * Author: Bhavya Deepthi Kothala
 * Program: CombineList
 * Description: 
 * 				The Program accepts two sorted linked lists and combine them into 
 *              another list which is in sorted order and print that list.
 *              The Combining and sorting the list is done in another written in 
 *              another class called MergeList.  
 *              
 **********************************************************************************/
public class CombineList 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		MergeList ML = new MergeList();
	
		//first list 
				 
		ListNode Firsthead = new ListNode(1);
		ListNode L1first = new ListNode(3);
		ListNode L1second = new ListNode(5);
		ListNode L1last = new ListNode(6);
		
		
		Firsthead.next = L1first;
		L1first.next = L1second;
		L1second.next = L1last;
		
		ListNode Temp;
		
		Temp = Firsthead;
		
		System.out.print("Given List 1:");
		//print the first list given by user
		while(Temp != null)
		{
			System.out.print(Temp.val);
			Temp = Temp.next;
			if(Temp != null)
			{
			 System.out.print("->");
			}
			
		}
		
		//second list
		ListNode Secondhead = new ListNode(4);
		ListNode L2first = new ListNode(7);
		ListNode L2last = new ListNode(8);
		
	
		Secondhead.next = L2first;
		L2first.next = L2last;
		//print the second list given by user
		Temp = Secondhead;
		System.out.print(" and List 2:");
		while(Temp != null)
		{
			System.out.print(Temp.val);
			Temp = Temp.next;
			if(Temp != null)
			{
			 System.out.print("->");
			}
			
		}
		// call a function to create a new list that combines the two lists in sorted  order
		ListNode newHead = ML.mergeTwoLists(Firsthead,Secondhead);
		System.out.print("\nreturn  ");
		//print the new list 
		while(newHead != null)
		{
			System.out.print(newHead.val);
			newHead = newHead.next;
			if(newHead != null)
			{
				System.out.print("->");
			}
		}
	}
}	