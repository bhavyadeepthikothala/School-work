/************************************************************************************************
 *@author bdk104(Bhavya Deepthi Kothala)
 *Program: Matrix Multiplication
 *Description: The program takes two matrices as input and multiply them produce the resultant matrix and prints it out
 *
 *Functions:
 *        This program has a function named "MatrixMultiply" that takes two matrices as the input and returns another
 *        matrix to the main function. The main function is used to take the test cases and also print the return matrix 
 *        from the function.  
 *
 *Working: 
 *        Inside the MatrixMultiply function :
 *        The outermost loop is used traverse through the rows of of first matrix 
 *        The second for loop is used to traverse column wise in the second matrix
 *        The Third for loop is used to traverse through the individual elemnets of both matrices
 *        and the loop control variable acts as the column index for first matrix and 
 *        as the row index in the second matrix. 
 *
 ************************************************************************************************/
public class MatrixMultiplication {

	public static void main(String[] args) 
	{
		// The test case for testing the function martix multiplication
		
		// TODO Auto-generated method stub
		
		
		int[][] A = {{1,2},{3,4},{6,7}}; //Elements of First Matrix. Each set is each row of the Matrix
		
		int[][] B = {{1,2,3},{4,5,6}};//Elements of Second Matrix. Each set is each row of Matrix
		
		/*******************************************************************************************
		 * Check if number of columns of first matrix is equal to number of rows of second Matrix 
		 * If equal Matrix Multiplication is possible and the resultant matrix will have 
		 * no. of rows = no. of rows of first matrix and
		 * no. of columns = no. of columns of second matrix
		 * If not equal Matrix Multiplication is not possible  
		 *******************************************************************************************/
		
		if(A[0].length == B.length)  
		{
			int[][] M = MatrixMultiply(A,B);
		
			for(int i = 0;i < A.length;i++)
			{
				for(int j = 0; j < B[0].length; j++ )
				{
					if(M[i][j] <= 9)
					{
					  System.out.print(M[i][j]+"  ");
					}
					else
					{
						 System.out.print(M[i][j]+" ");	
					}
				}
				System.out.println();
			}
		}
		else
		{
			System.out.println("Matrix Multiplication is not possible");
		}
		
	}
	
	
	
	/*******************************************************************************
	 * Function to Multiply two matrices
	 * Takes two matrices as input and retuns a resultant product matrix as output
	 *******************************************************************************/
	public static int[][] MatrixMultiply(int[][] A,int[][] B)
	{
		int[][] mul = new int[A.length][B[0].length];
		int sum = 0;
		
		 for(int i = 0; i < A.length; i++)   //Traverse first matrix 
		 {
			 for(int j = 0; j < B[0].length; j++) // Traverse second matrix
			 {
				 for(int k = 0; k < A[0].length; k++)
				 {
					sum = sum + A[i][k] * B[k][j]; 
				 }
				 mul[i][j] = sum;
				 sum = 0;
			 }
				 
		 }
		  return mul; //return resultant product matrix
		
	}
}	