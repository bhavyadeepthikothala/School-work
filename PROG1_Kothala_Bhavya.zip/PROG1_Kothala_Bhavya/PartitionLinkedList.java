/*********************************************************************************
 * Program : Partition Linked List
 * Description:
 *              	Partition the acquired linked list based on the given
 *                x value so that all the values less than x are stored in
 *                one list and the other values are stored in another list. 
 *                The second list maintains the relative order of the list 
 *                i.e, the nodes are connected in the same order as in the 
 *                original list.
 *                Now once we acquired both lists that satisfy our required 
 *                conditions join these two lists into a single list and return 
 *                that head Node 
 **********************************************************************************/
{
    public ListNode partition(ListNode head, int x)
    {
      ListNode Node1 = new ListNode(0);    // The head of nodes less than x
      ListNode Node2 = new ListNode(0);    // The head of nodes no less than x
      ListNode head1 = Node1;    //List for nodes less than x
      ListNode head2 = Node2;    // List for nodes that are not less than x
      while (head != null)
      {
          if(head.val < x)
          {
              head1.next = head;
              head1 = head1.next;
          }
          else
          {
              head2.next = head;
              head2 = head2.next;
          }
          head = head.next;
      }
      
      head1.next = Node2.next;  // Join the two sub lists together
      head2.next = null;
      
      return Node1.next;
    }
}
