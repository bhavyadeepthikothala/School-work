/**************************************************************************************************
 * Author: Bhavya Deepthi Kothala
 * Description: This Program takes the string as an input and returns the string in a reverse order
 * 
 * Fuctioning: First split the string into a string array and reverse them
 *             Now Concate them to form a string again by appending spaces in the middle.
 **************************************************************************************************/

public class ReverseString 
{
  public static void main(String [] args)
  {
	  String str = "the dog is white"; // string to be reversed
	
	  str = reverseString(str);
	  
	  System.out.println("reversed: " + str);
  }
  
  // function to reverse a string
  public static String reverseString(String str)
  {
	  String[] s = str.split(" "); // split the string based on the white character
	  String temp;
	  
	  for(int i = 0; i < s.length/2; i++) // store the string in a reverse order
	  {
		  temp = s[i]; 
		  s[i] = s[s.length - 1 - i];
		  s[s.length - 1 - i] = temp;
	  }
	  
	  String FinalString = s[0];
	  for(int j = 1; j < s.length; j++) // convert the string array into a string
	  {
          FinalString = FinalString.concat(" "); // concatenate a white space
		  FinalString = FinalString.concat(s[j]);// concatenate a word
	  }

	  return FinalString;
	  
  }
}
