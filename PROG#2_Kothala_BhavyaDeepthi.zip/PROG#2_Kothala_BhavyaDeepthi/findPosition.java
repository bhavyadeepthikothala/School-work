/***********************************************************************************************
 * Author: Bhavya Deepthi Kothala
 * Description: This program takes an array and a target value whose insertion position is 
 *              to be found out as inputs and returns the position at which the can be done. 
 *  
 * Function:
 *             I have used a  HashMap that has integer as key which represents the
 *             array index and that accepts integer as Value for the HashMap which
 *             represents the value stored at the index in the array.
 *             
 *             Take a array and index and find if that array index have a match for value 
 *             that is greater than the target in HashMap, if found return that index if 
 *             not proceed until the end of array. If end of array is reached the position 
 *             for insertion would be end of the array  
 *               
 ***********************************************************************************************/


import java.util.HashMap;

public class findPosition 
{
	public static void main(String[] args)
	{
		int[] arr = { 3, 5, 7, 9};
		int target = 6;
		System.out.println("The index at which the target value can be inserted is: " + FindPosition(arr, target));
	
	}
	//function to find the position for insertion
	public static int FindPosition(int[] arr, int target)
	{
		HashMap< Integer, Integer> map = new HashMap< Integer, Integer>(); // createing a hashmap
		
		
		for(int i = 0; i < arr.length; i++)
		{
			map.put(i, arr[i]);//insert into the hashmap
			
			if(map.get(i) > target)//get the value associated to that key
			{
				return i;
			} 
			
		}
		return arr.length;//insertion in the end of array
	}
	
}
