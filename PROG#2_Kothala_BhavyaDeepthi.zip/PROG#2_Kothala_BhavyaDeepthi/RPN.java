/**************************************************************************************************
 * Author: Bhavya Deepthi Kothala
 * Description: This Program takes string as input an returns an integer that is result of the 
 *              specified operations done on the numbers in the string array.
 *              
 * Functioning: The elements of the string array are compared to the operator values and is pushed 
 *              into the stack if it is a number if not number then checks if stack has two elements 
 *              to implement the operation and if possible do the operation and push the value into 
 *              the stack again and continue this until no elements of String array are left out and 
 *              there is only one value left in the stack.
 *              
 *              Once done, return the value left in the Stack 
 **************************************************************************************************/
import java.util.Stack; 

public class RPN 
{
	public static void main(String[] args)
	{
		String[] str = {"3", "2", "+", "4", "*", "3", "+"};
		System.out.println(Calculator(str));
	}
	
	// Function to implement the RPN Calculator
	public static int Calculator(String[] str)
	{
		
		Stack<Integer> st = new Stack<Integer>(); // create a stack
		String Operator = "+-*/";
		 
		 for(int i = 0; i<str.length; i++)
		 {
			 if(!Operator.contains(str[i]))// if the string array element is a number 
			 {
				 st.push(Integer.parseInt(str[i]));
			 }
			 else
			 {
				 if(st.isEmpty())
				 {
					 System.out.println("not possible");
				 }
				 
				 else
				 {
					 int a = st.pop();
					 int b = st.pop();
					 if(str[i].equals("+"))
					 {
						 st.push(a + b);
					 }
					 else if(str[i].equals("-"))
					 {
						 st.push(a - b);
					 }
					 else if(str[i].equals("*"))
					 {
						 st.push(a * b);
					 }
					 else if(str[i].equals("/"))
					 {
						 st.push(a / b);
					 }
				 }
			 }
		 }
		
		return st.pop();
	}

}
