/**************************************************************************************************
 * Author: Bhavya Deepthi Kothala
 * Description: This program takes an array and k value as an input  and returns the Kth Largest 
 *              value as output.
 *              
 * Functioning: Select a pivot value in this case the mid value of the array and palce it at the  
 *              end of the array and place the end of the array in the mid position.
 *               
 *              Now, comapre the other values of the arry with that pivot value and sort them such 
 *              that all values greater than the pivot are on left side of the pivot and all values 
 *              smaller than the pivot are on the right side of pivot.
 *               
 *              After sorting, move the pivot value back to the current start position . 
 *              Then check if pivot Index is equal to our K value. 
 *              If it is, 
 *                      return the value at that index.
 *              If pivot Index is greater than the K value then change the end of matrix to the
 *              Pivot - 1 Position which means we are throwing the other half of the matrix and now 
 *              searching in the remaining half which inturnis partitioning the array again
 *              
 *              If pivot Index is less than the K value, then set the start of the array as 
 *              Pivot + 1 and search again which means patition again.
 *                           
 **************************************************************************************************/

public class QuickSelect 
{
	public static void main(String[] args)
	{
		int[] arr = {9,14,3,11,24,143,60,2,90,12};
		int k = 3;
		System.out.println("the kth largest element is: " + findkthlargest(arr,k));
	}
	// function to find Kth  Largest
	public static int findkthlargest(int[] arr, int k)
	{
		int value = 0;
		int left = 0;
		int right = arr.length - 1;
		int pivot = partition(arr, left, right);// returns pivot Index
		
		while (left <= right)
		{
			if(pivot == k - 1)
			{
				return arr[pivot];
			}
			else if(pivot <  k)
			{
				left =  pivot + 1; //throw the left half
				pivot = partition(arr,left,right);
			}
			else
			{
				right = pivot - 1;// throw the right half
				pivot = partition(arr,left,right);
			}
		}
		return value;
	}
	
	//function to partition the array for searching the Kth Largest
	public static int partition(int[] arr, int start, int end)
	{
		int mid = (start + end) / 2;
		
		int pivotValue = arr[mid];
		int newStart = start;
		int newEnd = end;
		// swap the current end value with the Pivot value
		int temp = arr[mid];
		arr[mid] = arr[end];
		arr[end] = temp;
		
		while(true)
		{
			while(arr[newStart] > pivotValue && newStart < newEnd) // brings all the larger values of array to the front of array
			{
				newStart++;
			}
		
			while(arr[newEnd] <= pivotValue && newStart < newEnd)//pushes all  the smaller values of array to the back of array
			{
				newEnd--;
			}
		    
			// if current pointers are greater and smaller than the pivot Value then swap them 
			temp = arr[newStart];
			arr[newStart] = arr[newEnd];  
			arr[newEnd] = temp;
			
			if(newStart > newEnd || newStart == newEnd )
			{
				break;
			}
		}
		// swap the Pivot Value that is placed int the end of array at the beginning of parttion to the current start position
		temp = arr[newStart];
		arr[newStart] = arr[end];
		arr[end] = temp;
		
		return newStart; // return the Pivot Index
	}
	
}
