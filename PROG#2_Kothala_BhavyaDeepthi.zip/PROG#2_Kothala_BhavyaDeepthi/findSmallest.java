/**************************************************************************************************
 * Author: Bhavya Deepthi Kothala
 * Description: This program takes an array that is sorted but circular right shifted as an input
 *              and finds the smallest number in the array and returns it.
 *               
 **************************************************************************************************/


public class findSmallest 
{
	public static void main(String[] args)
	{
		int[] arr = {4, 5, 6, 7, 2};
		
		System.out.println("the smallest value  of the array is : " + FindSmallest(arr));
		
	}
	//function to find the smallest number
	public static int FindSmallest(int[] arr)
	{
		int small = -2456;
				
		for(int i = 0; i < arr.length; i++)
		{
			if(arr[i] > arr[i+1] && i != arr.length - 1)
			{
				return arr[i+1];
			}
			
		}
		
		return small;
		
	}
	

}
